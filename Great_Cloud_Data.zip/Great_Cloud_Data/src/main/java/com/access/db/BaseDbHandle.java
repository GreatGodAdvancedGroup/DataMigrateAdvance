package com.access.db;

import java.sql.Connection;

/**
 * 数据库公共方法接口 后续可添加更多方法
 * Created by 11195 on 2017/12/24.
 */
public interface BaseDbHandle {
    public void getAllColummnNames();
}
